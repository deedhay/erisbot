"use client";

import { useEffect, useState } from "react";
import Navigation from "../components/Navigation";
import { motion, AnimatePresence } from "framer-motion";

interface Command {
  name: string;
  description: string;
  aliases: string[];
  category: string;
  permissions?: string[];
  required_args?: any[];
  optional_args?: any[];
  examples?: string[];
}

export default function Commands() {
  const [commands, setCommands] = useState<Record<string, Command[]>>({});
  const [isDark, setIsDark] = useState(true);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", isDark);
  }, [isDark]);

  useEffect(() => {
    fetch("/commands.json")
      .then((res) => res.json())
      .then((data) => {
        setCommands(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const filteredCommands = Object.entries(commands).reduce((acc, [category, cmds]) => {
    const filtered = cmds.filter(cmd => 
      cmd.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cmd.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cmd.aliases.some(alias => alias.toLowerCase().includes(searchTerm.toLowerCase()))
    );
    if (filtered.length > 0) {
      acc[category] = filtered;
    }
    return acc;
  }, {} as Record<string, Command[]>);

  const displayedCommands = selectedCategory 
    ? { [selectedCategory]: filteredCommands[selectedCategory] || [] }
    : filteredCommands;

  const categories = Object.keys(commands).sort();
  const totalCommands = Object.values(commands).reduce((sum, cmds) => sum + cmds.length, 0);

  const formatPermissions = (permissions: string[] = []) => {
    if (!permissions || permissions.length === 0) return "None";
    return permissions.map(p => 
      p.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')
    ).join(', ');
  };

  const formatArguments = (required: any[] = [], optional: any[] = []) => {
    const total = required.length + optional.length;
    if (total === 0) return "None";
    const parts = [];
    if (required.length > 0) parts.push(`${required.length} required`);
    if (optional.length > 0) parts.push(`${optional.length} optional`);
    return parts.join(', ');
  };

  return (
    <div className={`min-h-screen relative overflow-hidden ${isDark ? "bg-black text-white" : "bg-white text-black"}`}>
      {/* Minimal background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(30)].map((_, i) => (
          <motion.div
            key={i}
            className={`absolute w-1 h-1 rounded-full ${isDark ? "bg-white" : "bg-black"}`}
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              opacity: [0.1, 0.4, 0.1],
            }}
            transition={{
              duration: Math.random() * 3 + 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      <Navigation isDark={isDark} setIsDark={setIsDark} />

      <main className="relative max-w-7xl mx-auto px-6 py-12">
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-4">
            <h1 className={`text-4xl md:text-5xl font-bold ${isDark ? "text-white" : "text-black"}`}>
              Command Reference
            </h1>
          </div>
          <p className={`${isDark ? "text-gray-400" : "text-gray-600"} mb-4`}>
            Explore all {totalCommands} commands across {categories.length} categories
          </p>
          <div className={`p-4 rounded-lg mb-6 ${isDark ? "bg-gray-900/50 border border-white/10" : "bg-gray-100/50 border border-black/10"}`}>
            <p className={`text-center ${isDark ? "text-gray-300" : "text-gray-700"}`}>
              Need more help? use <span className="font-mono font-semibold">?help</span> or <span className="font-mono font-semibold">/help</span> with our bot.
            </p>
          </div>
          <div className={`p-4 rounded-lg mb-6 ${isDark ? "bg-gray-900/50 border border-white/10" : "bg-gray-100/50 border border-black/10"}`}>
            <p className={`text-center ${isDark ? "text-gray-300" : "text-gray-700"}`}>
              Need more help? use <span className="font-mono font-semibold">?help</span> or <span className="font-mono font-semibold">/help</span> with our bot.
            </p>
          </div>

          {/* Search bar */}
          <div className="relative max-w-2xl">
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              <input
                type="text"
                placeholder="Search commands..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className={`w-full px-6 py-4 rounded-xl ${isDark ? "bg-gradient-to-r from-gray-900/90 to-black/90 border-white/10 text-white placeholder-gray-500" : "bg-gradient-to-r from-gray-100/90 to-white/90 border-black/10 text-black placeholder-gray-500"} border focus:outline-none transition-all duration-300`}
              />
            </motion.div>
          </div>
        </motion.div>

        {/* Category tabs */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="mb-8 overflow-x-auto pb-4"
        >
          <div className="flex gap-3 min-w-max">
            <motion.button
              onClick={() => setSelectedCategory(null)}
              className={`px-6 py-3 rounded-lg font-medium transition-all duration-300 flex items-center gap-2 ${
                selectedCategory === null
                  ? isDark 
                    ? "bg-white text-black shadow-lg" 
                    : "bg-black text-white shadow-lg"
                  : isDark
                    ? "bg-gray-900/50 border border-white/10 text-gray-400 hover:border-white/30 hover:text-white"
                    : "bg-gray-100/50 border border-black/10 text-gray-600 hover:border-black/30 hover:text-black"
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <span>All Commands</span>
              <span className={`text-xs px-2 py-1 rounded ${isDark ? "bg-white/10" : "bg-black/10"}`}>
                {totalCommands}
              </span>
            </motion.button>
            {categories.map((category, index) => (
              <motion.button
                key={category}
                onClick={() => setSelectedCategory(category)}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: index * 0.02 }}
                className={`px-6 py-3 rounded-lg font-medium transition-all duration-300 flex items-center gap-2 capitalize ${
                  selectedCategory === category
                    ? isDark 
                      ? "bg-white text-black shadow-lg" 
                      : "bg-black text-white shadow-lg"
                    : isDark
                      ? "bg-gray-900/50 border border-white/10 text-gray-400 hover:border-white/30 hover:text-white"
                      : "bg-gray-100/50 border border-black/10 text-gray-600 hover:border-black/30 hover:text-black"
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <span>{category}</span>
                <span className={`text-xs px-2 py-1 rounded ${isDark ? "bg-white/10" : "bg-black/10"}`}>
                  {commands[category]?.length || 0}
                </span>
              </motion.button>
            ))}
          </div>
        </motion.div>

        {loading ? (
          <div className="text-center py-12">
            <motion.div
              className={`inline-block w-12 h-12 border-4 ${isDark ? "border-white border-t-transparent" : "border-black border-t-transparent"} rounded-full`}
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            />
            <p className={`mt-4 ${isDark ? "text-gray-400" : "text-gray-600"}`}>Loading commands...</p>
          </div>
        ) : (
          <AnimatePresence mode="wait">
            <motion.div
              key={selectedCategory || "all"}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="space-y-8"
            >
              {Object.entries(displayedCommands).map(([category, cmds], categoryIndex) => (
                <motion.div
                  key={category}
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ duration: 0.5, delay: categoryIndex * 0.05 }}
                >
                  {!selectedCategory && (
                    <motion.h2 
                      className={`text-2xl font-bold mb-4 capitalize flex items-center gap-3 ${isDark ? "text-white" : "text-black"}`}
                      initial={{ x: -20 }}
                      animate={{ x: 0 }}
                    >
                      <span>{category}</span>
                      <span className={`text-sm ${isDark ? "text-gray-500" : "text-gray-600"}`}>({cmds.length})</span>
                    </motion.h2>
                  )}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {cmds.map((cmd, cmdIndex) => (
                      <motion.div
                        key={cmd.name}
                        initial={{ scale: 0.9, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        transition={{ duration: 0.3, delay: cmdIndex * 0.02 }}
                        whileHover={{ 
                          scale: 1.03,
                          y: -5,
                          transition: { duration: 0.2 }
                        }}
                        className={`group relative p-5 rounded-xl ${isDark ? "bg-gradient-to-br from-gray-900/80 to-black/80 border-white/10 hover:border-white/30" : "bg-gradient-to-br from-gray-100/80 to-white/80 border-black/10 hover:border-black/30"} border transition-all duration-300 cursor-pointer overflow-hidden`}
                      >
                        {/* Animated background gradient */}
                        <motion.div
                          className={`absolute inset-0 ${isDark ? "bg-gradient-to-br from-white/5 to-transparent" : "bg-gradient-to-br from-black/5 to-transparent"} opacity-0 group-hover:opacity-100 transition-opacity duration-300`}
                          animate={{
                            backgroundPosition: ["0% 0%", "100% 100%"],
                          }}
                          transition={{ duration: 3, repeat: Infinity, repeatType: "reverse" }}
                        />

                        <div className="relative z-10">
                          <div className="flex items-start justify-between gap-2 mb-3">
                            <h3 className={`text-lg font-bold ${isDark ? "text-white group-hover:text-gray-200" : "text-black group-hover:text-gray-800"} transition-colors`}>
                              {cmd.name.replace(/\./g, ' ')}
                            </h3>
                          </div>

                          {cmd.aliases && cmd.aliases.length > 0 && (
                            <motion.div 
                              className="flex flex-wrap gap-2 mb-3"
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              transition={{ delay: 0.1 }}
                            >
                              {cmd.aliases.map((alias, aliasIndex) => (
                                <motion.span
                                  key={alias}
                                  initial={{ scale: 0 }}
                                  animate={{ scale: 1 }}
                                  transition={{ delay: cmdIndex * 0.02 + aliasIndex * 0.05 }}
                                  className={`text-xs px-2 py-1 rounded-md ${isDark ? "bg-white/5 border-white/10 text-gray-400" : "bg-black/5 border-black/10 text-gray-600"} border`}
                                  whileHover={{ scale: 1.1 }}
                                >
                                  {alias}
                                </motion.span>
                              ))}
                            </motion.div>
                          )}

                          <div className="mb-3">
                            <p className={`text-sm ${isDark ? "text-gray-400" : "text-gray-600"} leading-relaxed`}>
                              {cmd.description}
                            </p>
                          </div>

                          <motion.div 
                            className={`flex items-center gap-2 text-xs ${isDark ? "text-gray-500" : "text-gray-600"}`}
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: 0.2 }}
                          >
                            <span>Arguments</span>
                            <div className={`flex-1 h-px ${isDark ? "bg-white/10" : "bg-black/10"}`} />
                          </motion.div>
                          <motion.div 
                            className={`mt-2 text-xs ${isDark ? "text-gray-600" : "text-gray-500"}`}
                          >
                            {formatArguments(cmd.required_args, cmd.optional_args)}
                          </motion.div>

                          <motion.div 
                            className={`mt-3 flex items-center gap-2 text-xs ${isDark ? "text-gray-500" : "text-gray-600"}`}
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: 0.25 }}
                          >
                            <span>Permissions</span>
                            <div className={`flex-1 h-px ${isDark ? "bg-white/10" : "bg-black/10"}`} />
                          </motion.div>
                          <motion.div 
                            className="mt-2"
                          >
                            <span className={`text-xs px-3 py-1 rounded-full ${isDark ? "bg-white/10 text-gray-400 border-white/20" : "bg-black/10 text-gray-600 border-black/20"} border`}>
                              {formatPermissions(cmd.permissions)}
                            </span>
                          </motion.div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </AnimatePresence>
        )}

        {!loading && Object.keys(filteredCommands).length === 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-12"
          >
            <p className={`text-lg ${isDark ? "text-gray-400" : "text-gray-600"}`}>
              No commands found matching your search
            </p>
          </motion.div>
        )}
      </main>
    </div>
  );
}
