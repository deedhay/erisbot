# Eris Bot Website

A modern, minimal Next.js website for the Eris Discord bot.

## Features

- Clean black/red/white design theme
- No emojis, plain English throughout
- Commands page that displays bot commands by category
- Status page with live bot statistics
- Discord OAuth authentication
- Responsive design with smooth animations

## Development

```bash
npm install
npm run dev
```

Visit `http://localhost:5000`

## Building Commands Data

The commands are auto-generated from the Python plugin files:

```bash
npm run generate-commands
```

This scans all plugin files (excluding `help.py`) and generates `data/commands.json`.

## Building for Production

```bash
npm run build
npm start
```

## Deploying to Cloudflare Pages

1. Connect your repository to Cloudflare Pages
2. Set build command: `npm run build`
3. Set build output directory: `.next`
4. Add environment variables:
   - `DISCORD_CLIENT_ID`
   - `DISCORD_CLIENT_SECRET`
   - `NEXTAUTH_SECRET`
   - `NEXTAUTH_URL`

## Configuration

### Environment Variables

Create a `.env.local` file:

```env
NEXTAUTH_URL=http://localhost:5000
NEXTAUTH_SECRET=your-secret-key
DISCORD_CLIENT_ID=your-client-id
DISCORD_CLIENT_SECRET=your-client-secret
```

### Bot Configuration

The bot sends statistics to `/api/stats` every 60 seconds. Configure the endpoint in `config.toml`:

```toml
[website]
api_endpoint = "http://localhost:5000/api/stats"
update_interval = 60
```

## TODO

- [ ] Replace placeholder logo with actual bot profile picture at `public/bot-avatar.png`
- [ ] Add user's shared servers display after Discord OAuth login
- [ ] Add command usage examples
- [ ] Add bot invite link to navigation

## Tech Stack

- Next.js 14
- TypeScript
- Tailwind CSS
- Framer Motion
- NextAuth.js
